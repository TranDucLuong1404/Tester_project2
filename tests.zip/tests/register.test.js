const { Builder, By, until } = require('selenium-webdriver');
require('chromedriver');
const XLSX = require('xlsx');
const path = require('path');

(async function testRegister() {
    let driver = await new Builder().forBrowser('chrome').build();
    const reportData = []; // Mảng lưu kết quả để ghi vào file báo cáo

    try {
        // Đọc dữ liệu từ file Excel
        const excelFilePath = path.join(__dirname, 'test_data_register.xlsx');
        const workbook = XLSX.readFile(excelFilePath);
        const sheetName = workbook.SheetNames[0]; // Lấy sheet đầu tiên
        const worksheet = workbook.Sheets[sheetName];
        const data = XLSX.utils.sheet_to_json(worksheet); // Chuyển sheet thành mảng JSON

        // Duyệt qua từng dòng trong file Excel
        for (const row of data) {
            const username = row.username;
            const email = row.email;
            const password = row.password;
            const expectedResult = row.expected_result;

            console.log(`Đang kiểm thử với: ${username}, ${email}, ${password}`);

            // 1. Mở trang đăng ký
            await driver.get('http://localhost:3001/register');

            // 2. Chờ trường username xuất hiện để đảm bảo trang đã load xong
            await driver.wait(until.elementLocated(By.name('username')), 10000);

            // 3. Điền thông tin từ Excel vào các trường
            await driver.findElement(By.name('username')).sendKeys(username);
            await driver.findElement(By.name('email')).sendKeys(email);
            await driver.findElement(By.name('password')).sendKeys(password);

            // 4. Nhấn nút đăng ký
            await driver.findElement(By.css('button[type="submit"]')).click();

            let actualResult = '';
            let status = '';

            try {
                // 5. Chờ và kiểm tra chuyển hướng đến trang login
                await driver.wait(until.urlIs('http://localhost:3001/login'), 10000);
                actualResult = 'Chuyển hướng đến trang đăng nhập';
                status = expectedResult.includes('hợp lệ') ? 'Passede' : 'Failed';
            } catch (error) {
                // Nếu không chuyển hướng, kiểm tra thông báo lỗi
                try {
                    const errorElement = await driver.findElement(By.css('.bg-red-100'));
                    actualResult = await errorElement.getText();
                    status = expectedResult.includes(actualResult) ? 'Passed' : 'Failed';
                } catch (err) {
                    actualResult = 'Không có thông báo lỗi';
                    status = 'Failed';
                }
            }

            // Ghi nhận kết quả vào mảng
            reportData.push({
                username,
                email,
                password,
                expected_result: expectedResult,
                actual_result: actualResult,
                status
            });

            console.log(`Kết quả cho ${username}: ${status}`);
        }
    } catch (error) {
        console.error('Lỗi trong quá trình đăng ký:', error);
    } finally {
        // Đóng trình duyệt sau khi hoàn thành
        await driver.quit();

        // Ghi kết quả vào file Excel báo cáo
        const reportWorkbook = XLSX.utils.book_new();
        const reportSheet = XLSX.utils.json_to_sheet(reportData);
        XLSX.utils.book_append_sheet(reportWorkbook, reportSheet, 'Report');
        const reportFilePath = path.join(__dirname, 'test_register_report.xlsx');
        XLSX.writeFile(reportWorkbook, reportFilePath);
        console.log(`Báo cáo đã được ghi vào: ${reportFilePath}`);
    }
})();